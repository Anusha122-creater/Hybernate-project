package org.hibernate;

public @interface Session {

}
