package org.hibernate;

public interface SessionFactory {

	void close();

}
